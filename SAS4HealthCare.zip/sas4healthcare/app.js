const translations = {
en: {"tagline": "Smart Appointment System for Healthcare", "login": "Login", "register": "Register", "phoneNumber": "Phone Number", "password": "Password", "loginBtn": "Login", "doctorName": "Doctor Name", "specialty": "Specialty", "generalMedicine": "General Medicine", "cardiology": "Cardiology", "dermatology": "Dermatology", "orthopedics": "Orthopedics", "pediatrics": "Pediatrics", "neurology": "Neurology", "ophthalmology": "Ophthalmology", "ent": "ENT", "gynecology": "Gynecology", "urology": "Urology", "psychiatry": "Psychiatry", "dental": "Dental", "clinicName": "Clinic Name", "confirmPassword": "Confirm Password", "subscriptionInfo": "Monthly subscription: 150,000 IQD/doctor | Free for patients", "registerBtn": "Register & Subscribe", "dashboard": "Dashboard", "queue": "Queue", "patients": "Patients", "subscription": "Subscription", "settings": "Settings", "logout": "Logout", "totalPatients": "Total Patients", "todayServed": "Served Today", "inQueue": "In Queue", "todayAppointments": "Today Appointments", "currentQueue": "Current Queue", "viewAll": "View All", "noQueue": "No patients in queue", "noPatients": "No patients yet", "recentPatients": "Recent Patients", "subscriptionStatus": "Subscription Status", "status": "Status", "active": "Active", "inactive": "Inactive", "expires": "Expires", "nowServing": "Now Serving", "noOneServing": "No one being served", "callNext": "Call Next Patient", "addPatient": "Add Patient", "waitingList": "Waiting List", "patients_lower": "patients", "servedToday": "Served Today", "noOneServed": "No one served yet today", "searchPatients": "Search patients...", "addNewPatient": "Add New Patient", "back": "Back", "editProfile": "Edit Profile", "personalInfo": "Personal Info", "reports": "Reports", "labTests": "Lab Tests", "visitHistory": "Visit History", "fullName": "Full Name", "age": "Age", "gender": "Gender", "male": "Male", "female": "Female", "phone": "Phone", "bloodType": "Blood Type", "address": "Address", "allergies": "Allergies", "chronicDiseases": "Chronic Diseases", "notes": "Notes", "addReport": "Add Report", "noReports": "No reports yet", "addTest": "Add Lab Test", "noTests": "No lab tests yet", "noVisits": "No visit history yet", "reportTitle": "Report Title", "reportDate": "Report Date", "reportType": "Report Type", "diagnosis": "Diagnosis", "prescription": "Prescription", "referral": "Referral", "followUp": "Follow-up", "surgery": "Surgery Report", "other": "Other", "reportContent": "Report Content", "testName": "Test Name", "testDate": "Test Date", "testResult": "Test Result", "testStatus": "Status", "pending": "Pending", "completed": "Completed", "abnormal": "Abnormal", "addToQueue": "Add to Queue", "cancel": "Cancel", "save": "Save", "close": "Close", "subscriptionPlan": "Subscription Plan", "doctorPlan": "Doctor Plan", "iqd": "IQD", "month": "month", "unlimitedPatients": "Unlimited Patients", "queueManagement": "Queue Management", "patientRecords": "Patient Records & Reports", "labTestRecords": "Lab Test Records", "multiLang": "Multi-language Support", "whatsappNotif": "WhatsApp Notifications", "subscribeNow": "Subscribe Now", "patientPlan": "Patient Plan", "free": "Free", "queueBooking": "Queue Booking", "viewReports": "View Reports", "viewTests": "View Lab Tests", "turnNotif": "Turn Notifications", "noPayment": "No payment required", "paymentMethods": "Payment Methods", "paymentTitle": "Complete Payment", "plan": "Plan", "duration": "Duration", "1month": "1 Month", "total": "Total", "paymentInstructions": "Payment Instructions", "payStep1": "Send 150,000 IQD via FastPay or FIB to: +9647504909260", "payStep2": "Take a screenshot of the payment receipt", "payStep3": "Send the receipt via WhatsApp to: +9647504909260", "payStep4": "After approval, your doctor account will be activated in the app", "openWhatsApp": "Open WhatsApp", "languageSettings": "Language Settings", "clinicSettings": "Clinic Settings", "workingHours": "Working Hours", "avgConsultTime": "Avg. Consultation Time (min)", "saveChanges": "Save Changes", "aboutApp": "About App", "aboutDesc": "Smart Appointment System for Healthcare - manage your clinic queue, patient records, and lab tests all in one place.", "version": "Version", "support": "Support", "yourTurn": "Its Your Turn!", "okay": "OK", "patientAdded": "Patient added successfully", "reportAdded": "Report added successfully", "testAdded": "Lab test added successfully", "settingsSaved": "Settings saved", "loginFailed": "Login failed. Check your credentials.", "registerFailed": "Registration failed. Please check all fields.", "passwordsNotMatch": "Passwords do not match", "queueEmpty": "No patients in queue", "patientCalled": "Patient called", "sendTo": "Send to: ", "sendReceipt": "Send receipt to: ", "yearsOld": "years old", "visitedOn": "Visited on", "remove": "Remove", "callPatient": "Call", "notApproved": "Account pending approval", "phoneExists": "Phone number already registered"},
ku: {"tagline": "سیستەمی زیرەکی نۆبەت بۆ تەندروستی", "login": "چوونەژوور", "register": "تۆمارکردن", "phoneNumber": "ژمارەی مۆبایل", "password": "وشەی نهێنی", "loginBtn": "چوونەژوور", "doctorName": "ناوی دکتۆر", "specialty": "شارەزایی", "generalMedicine": "پزیشکی گشتی", "cardiology": "دڵ و هەناو", "dermatology": "پێست", "orthopedics": "ئێسک و جومگە", "pediatrics": "مناڵان", "neurology": "دەمار", "ophthalmology": "چاو", "ent": "گویلاق و لووت و گوێ", "gynecology": "ژنان", "urology": "کۆئەندامی میز", "psychiatry": "دەروون", "dental": "دان", "clinicName": "ناوی کلینیک", "confirmPassword": "دڵنیاکردنەوەی وشەی نهێنی", "subscriptionInfo": "بەشداری مانگانە: ١٥٠,٠٠٠ دینار/دکتۆر | بۆ نەخۆشان بەخۆرایی", "registerBtn": "تۆمارکردن و بەشداری", "dashboard": "داشبۆرد", "queue": "نۆبەت", "patients": "نەخۆشان", "subscription": "بەشداری", "settings": "ڕێکخستن", "logout": "چوونەدەر", "totalPatients": "کۆی نەخۆش", "todayServed": "خزمەتکراو ئەمڕۆ", "inQueue": "لە نۆبەت", "todayAppointments": "نۆبەتی ئەمڕۆ", "currentQueue": "نۆبەتی ئێستا", "viewAll": "هەمووی", "noQueue": "هیچ نەخۆشێک لە نۆبەت نییە", "noPatients": "هیچ نەخۆشێک نییە", "recentPatients": "نەخۆشانی کۆتایی", "subscriptionStatus": "بارودۆخی بەشداری", "status": "بارودۆخ", "active": "چالاک", "inactive": "ناچالاک", "expires": "بەسەرچوون", "nowServing": "ئێستا خزمەت دەکرێت", "noOneServing": "هیچ کەسێک خزمەت ناکرێت", "callNext": "بانگکردنی نەخۆشی داهاتوو", "addPatient": "زیادکردنی نەخۆش", "waitingList": "لیستی چاوەڕوان", "patients_lower": "نەخۆش", "servedToday": "خزمەتکراو ئەمڕۆ", "noOneServed": "هیچ کەسێک ئەمڕۆ خزمەت نەکراوە", "searchPatients": "گەڕان بۆ نەخۆش...", "addNewPatient": "زیادکردنی نەخۆشی نوێ", "back": "گەڕانەوە", "editProfile": "دەستکاری پرۆفایل", "personalInfo": "زانیاری کەسی", "reports": "ڕاپۆرتەکان", "labTests": "تاقیکردنەوەکانی تاقیگە", "visitHistory": "مێژووی سەردان", "fullName": "ناوی تەواو", "age": "تەمەن", "gender": "ڕەگەز", "male": "نێر", "female": "مێ", "phone": "مۆبایل", "bloodType": "جۆری خوێن", "address": "ناونیشان", "allergies": "حەساسییەت", "chronicDiseases": "نەخۆشییە درێژخایەنەکان", "notes": "تێبینی", "addReport": "زیادکردنی ڕاپۆرت", "noReports": "هیچ ڕاپۆرتێک نییە", "addTest": "زیادکردنی تاقیکردنەوە", "noTests": "هیچ تاقیکردنەوەیەک نییە", "noVisits": "هیچ مێژووی سەردانێک نییە", "reportTitle": "ناونیشانی ڕاپۆرت", "reportDate": "بەرواری ڕاپۆرت", "reportType": "جۆری ڕاپۆرت", "diagnosis": "دیانۆز", "prescription": "دەرماننووسی", "referral": "ناردن", "followUp": "چاودێری", "surgery": "ڕاپۆرتی نەشتەرگەری", "other": "هیتر", "reportContent": "ناوەڕۆکی ڕاپۆرت", "testName": "ناوی تاقیکردنەوە", "testDate": "بەرواری تاقیکردنەوە", "testResult": "ئەنجامی تاقیکردنەوە", "testStatus": "بارودۆخ", "pending": "چاوەڕوان", "completed": "تەواو", "abnormal": "نائاسایی", "addToQueue": "زیادکردن بۆ نۆبەت", "cancel": "پاشگەزبوونەوە", "save": "پاشکەوتکردن", "close": "داخستن", "subscriptionPlan": "پلانی بەشداری", "doctorPlan": "پلانی دکتۆر", "iqd": "دینار", "month": "مانگ", "unlimitedPatients": "نەخۆشی بێسنوور", "queueManagement": "بەڕێوەبردنی نۆبەت", "patientRecords": "تۆماری نەخۆش و ڕاپۆرت", "labTestRecords": "تۆماری تاقیکردنەوە", "multiLang": "پشتگیری فرەزمان", "whatsappNotif": "ئاگاداری وەتسئەپ", "subscribeNow": "بەشداری ئێستا", "patientPlan": "پلانی نەخۆش", "free": "بەخۆرایی", "queueBooking": "نۆبەتگرتن", "viewReports": "بینینی ڕاپۆرتەکان", "viewTests": "بینینی تاقیکردنەوەکان", "turnNotif": "ئاگاداری نۆبەت", "noPayment": "پارەدان پێویست نییە", "paymentMethods": "شێوازکانی پارەدان", "paymentTitle": "تەواوکردنی پارەدان", "plan": "پلان", "duration": "ماوە", "1month": "١ مانگ", "total": "کۆی گشتی", "paymentInstructions": "ڕێنمایی پارەدان", "payStep1": "١٥٠,٠٠٠ دینار بنێرە لە رێگەی FastPay یان FIB بۆ ژمارە: +9647504909260", "payStep2": "وێنەی پسوولەی پارەدان بگرە", "payStep3": "پسوولەکە بنێرە لە رێگەی WhatsApp بۆ: +9647504909260", "payStep4": "لە دوای پشتڕاستکردنەوە و پەسەندکردن، هەژماری دکتۆرەکەت لەناو ئەپەکە چالاک دەکرێت", "openWhatsApp": "کردنەوەی وەتسئەپ", "languageSettings": "ڕێکخستنی زمان", "clinicSettings": "ڕێکخستنی کلینیک", "workingHours": "کاتەکانی کار", "avgConsultTime": "تێکڕای کاتی چاوپێکەوتن (خولەک)", "saveChanges": "پاشکەوتکردنی گۆڕانەکان", "aboutApp": "دەربارەی ئەپ", "aboutDesc": "سیستەمی زیرەکی نۆبەت بۆ تەندروستی - نۆبەت، تۆماری نەخۆش و تاقیکردنەوە هەموو لە شوێنێکدا بەڕێوەبگرە.", "version": "وەشاندن", "support": "پشتگیری", "yourTurn": "نۆبەتی تۆیە!", "okay": "باشە", "patientAdded": "نەخۆش بە سەرکەوتوویی زیادکرا", "reportAdded": "ڕاپۆرت بە سەرکەوتوویی زیادکرا", "testAdded": "تاقیکردنەوە بە سەرکەوتوویی زیادکرا", "settingsSaved": "ڕێکخستنەکان پاشکەوتکران", "loginFailed": "چوونەژوور سەرنەکەوت. زانیارییەکانت بپشکنە.", "registerFailed": "تۆمارکردن سەرنەکەوت. هەموو خانەکان بپڕن.", "passwordsNotMatch": "وشەی نهێنی یەک ناگرنەوە", "queueEmpty": "هیچ نەخۆشێک لە نۆبەت نییە", "patientCalled": "نەخۆش بانگکرا", "sendTo": "بنێرە بۆ: ", "sendReceipt": "پسوولە بنێرە بۆ: ", "yearsOld": "ساڵ", "visitedOn": "سەردانی", "remove": "سڕینەوە", "callPatient": "بانگ", "notApproved": "هەژمار چاوەڕوانی پەسەندکردنە", "phoneExists": "ژمارەی مۆبایل پێشتر تۆمارکراوە"},
ar: {"tagline": "نظام ذكي للمواعيد الصحية", "login": "تسجيل الدخول", "register": "إنشاء حساب", "phoneNumber": "رقم الهاتف", "password": "كلمة المرور", "loginBtn": "دخول", "doctorName": "اسم الطبيب", "specialty": "التخصص", "generalMedicine": "طب عام", "cardiology": "قلب وأوعية", "dermatology": "جلدية", "orthopedics": "عظمية", "pediatrics": "أطفال", "neurology": "أعصاب", "ophthalmology": "عينية", "ent": "أنف أذن حنجرة", "gynecology": "نسائية", "urology": "مسالك بولية", "psychiatry": "نفسية", "dental": "أسنان", "clinicName": "اسم العيادة", "confirmPassword": "تأكيد كلمة المرور", "subscriptionInfo": "الاشتراك الشهري: ١٥٠,٠٠٠ دينار/طبيب | مجاني للمرضى", "registerBtn": "تسجيل واشتراك", "dashboard": "لوحة التحكم", "queue": "المواعيد", "patients": "المرضى", "subscription": "الاشتراك", "settings": "الإعدادات", "logout": "خروج", "totalPatients": "إجمال المرضى", "todayServed": "تم الخدمة اليوم", "inQueue": "في الانتظار", "todayAppointments": "مواعيد اليوم", "currentQueue": "القائمة الحالية", "viewAll": "عرض الكل", "noQueue": "لا يوجد مرضى في القائمة", "noPatients": "لا يوجد مرضى", "recentPatients": "المرضى الأخيرون", "subscriptionStatus": "حالة الاشتراك", "status": "الحالة", "active": "نشط", "inactive": "غير نشط", "expires": "ينتهي في", "nowServing": "يتم الخدمة الآن", "noOneServing": "لا يتم خدمة أحد", "callNext": "استدعاء المريض التالي", "addPatient": "إضافة مريض", "waitingList": "قائمة الانتظار", "patients_lower": "مرضى", "servedToday": "تم الخدمة اليوم", "noOneServed": "لم يتم خدمة أحد اليوم", "searchPatients": "البحث عن مرضى...", "addNewPatient": "إضافة مريض جديد", "back": "رجوع", "editProfile": "تعديل الملف", "personalInfo": "المعلومات الشخصية", "reports": "التقارير", "labTests": "فحوصات المختبر", "visitHistory": "سجل الزيارات", "fullName": "الاسم الكامل", "age": "العمر", "gender": "الجنس", "male": "ذكر", "female": "أنثى", "phone": "الهاتف", "bloodType": "فصيلة الدم", "address": "العنوان", "allergies": "الحساسية", "chronicDiseases": "الأمراض المزمنة", "notes": "ملاحظات", "addReport": "إضافة تقرير", "noReports": "لا توجد تقارير", "addTest": "إضافة فحص", "noTests": "لا توجد فحوصات", "noVisits": "لا يوجد سجل زيارات", "reportTitle": "عنوان التقرير", "reportDate": "تاريخ التقرير", "reportType": "نوع التقرير", "diagnosis": "تشخيص", "prescription": "وصفة طبية", "referral": "إحالة", "followUp": "متابعة", "surgery": "تقرير جراحة", "other": "أخرى", "reportContent": "محتوى التقرير", "testName": "اسم الفحص", "testDate": "تاريخ الفحص", "testResult": "نتيجة الفحص", "testStatus": "الحالة", "pending": "قيد الانتظار", "completed": "مكتمل", "abnormal": "غير طبيعي", "addToQueue": "إضافة للقائمة", "cancel": "إلغاء", "save": "حفظ", "close": "إغلاق", "subscriptionPlan": "خطة الاشتراك", "doctorPlan": "خطة الطبيب", "iqd": "دينار", "month": "شهر", "unlimitedPatients": "مرضى بلا حدود", "queueManagement": "إدارة المواعيد", "patientRecords": "سجلات وتقارير المرضى", "labTestRecords": "سجلات الفحوصات", "multiLang": "دعم متعدد اللغات", "whatsappNotif": "إشعارات واتساب", "subscribeNow": "اشترك الآن", "patientPlan": "خطة المريض", "free": "مجاني", "queueBooking": "حجز موعد", "viewReports": "عرض التقارير", "viewTests": "عرض الفحوصات", "turnNotif": "إشعارات الدور", "noPayment": "لا حاجة للدفع", "paymentMethods": "طرق الدفع", "paymentTitle": "إتمام الدفع", "plan": "الخطة", "duration": "المدة", "1month": "شهر واحد", "total": "المجموع", "paymentInstructions": "تعليمات الدفع", "payStep1": "أرسل ١٥٠,٠٠٠ دينار عبر FastPay أو FIB إلى الرقم: +9647504909260", "payStep2": "التقط صورة لإيصال الدفع", "payStep3": "أرسل الإيصال عبر WhatsApp إلى: +9647504909260", "payStep4": "بعد التحقق والموافقة، سيتم تفعيل حسابك في التطبيق", "openWhatsApp": "فتح واتساب", "languageSettings": "إعدادات اللغة", "clinicSettings": "إعدادات العيادة", "workingHours": "ساعات العمل", "avgConsultTime": "متوسط وقت الاستشارة (دقيقة)", "saveChanges": "حفظ التغييرات", "aboutApp": "عن التطبيق", "aboutDesc": "نظام ذكي للمواعيد الصحية - أدر مواعيد عيادتك وسجلات المرضى والفحوصات في مكان واحد.", "version": "الإصدار", "support": "الدعم", "yourTurn": "حان دورك!", "okay": "حسناً", "patientAdded": "تمت إضافة المريض بنجاح", "reportAdded": "تمت إضافة التقرير بنجاح", "testAdded": "تمت إضافة الفحص بنجاح", "settingsSaved": "تم حفظ الإعدادات", "loginFailed": "فشل تسجيل الدخول. تحقق من بياناتك.", "registerFailed": "فشل التسجيل. يرجى ملء جميع الحقول.", "passwordsNotMatch": "كلمات المرور غير متطابقة", "queueEmpty": "لا يوجد مرضى في القائمة", "patientCalled": "تم استدعاء المريض", "sendTo": "أرسل إلى: ", "sendReceipt": "أرسل الإيصال إلى: ", "yearsOld": "سنة", "visitedOn": "زيارة في", "remove": "حذف", "callPatient": "استدعاء", "notApproved": "الحساب بانتظار الموافقة", "phoneExists": "رقم الهاتف مسجل مسبقاً"}
};

// ===== APP STATE =====
let currentLang = 'en';
let currentUser = null;
let currentPatientId = null;

// ===== DATA STORE =====
function getDoctors(){return JSON.parse(localStorage.getItem('sas4hc_doctors')||'[]');}
function saveDoctors(d){localStorage.setItem('sas4hc_doctors',JSON.stringify(d));}
function getPatients(){return JSON.parse(localStorage.getItem('sas4hc_patients')||'[]');}
function savePatients(d){localStorage.setItem('sas4hc_patients',JSON.stringify(d));}
function getQueue(){return JSON.parse(localStorage.getItem('sas4hc_queue')||'[]');}
function saveQueue(d){localStorage.setItem('sas4hc_queue',JSON.stringify(d));}
function getServed(){return JSON.parse(localStorage.getItem('sas4hc_served')||'[]');}
function saveServed(d){localStorage.setItem('sas4hc_served',JSON.stringify(d));}
function getSettings2(){return JSON.parse(localStorage.getItem('sas4hc_settings')||'{}');}
function saveSettings2(d){localStorage.setItem('sas4hc_settings',JSON.stringify(d));}
function t(key){return translations[currentLang]?.[key]||translations.en?.[key]||key;}

function applyLanguage(lang){
    currentLang=lang;
    var isRTL=lang==='ku'||lang==='ar';
    document.documentElement.dir=isRTL?'rtl':'ltr';
    document.documentElement.lang=lang;
    document.querySelectorAll('[data-i18n]').forEach(function(el){el.textContent=t(el.getAttribute('data-i18n'));});
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function(el){el.placeholder=t(el.getAttribute('data-i18n-placeholder'));});
    document.querySelectorAll('.lang-btn').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-lang')===lang);});
    document.querySelectorAll('input[name="appLang"]').forEach(function(r){r.checked=r.value===lang;});
    localStorage.setItem('sas4hc_lang',lang);
    renderAll();
}

function isToday(dateStr){if(!dateStr)return false;var d=new Date(dateStr);var now=new Date();return d.toDateString()===now.toDateString();}
function getNextQueueNum(){
    var served=getServed().filter(function(s){return s.doctorId===currentUser?.id&&isToday(s.servedAt);});
    var queue=getQueue().filter(function(q){return q.doctorId===currentUser?.id;});
    return served.length+queue.length+1;
}

// ===== INIT =====
function init(){
    var savedLang=localStorage.getItem('sas4hc_lang')||'en';
    applyLanguage(savedLang);
    var savedUser=localStorage.getItem('sas4hc_currentUser');
    if(savedUser){currentUser=JSON.parse(savedUser);showMainApp();}
    document.querySelectorAll('.lang-btn').forEach(function(b){b.addEventListener('click',function(){applyLanguage(b.getAttribute('data-lang'));});});
    document.querySelectorAll('input[name="appLang"]').forEach(function(r){r.addEventListener('change',function(){applyLanguage(r.value);});});
    document.querySelectorAll('.tab-btn').forEach(function(b){
        b.addEventListener('click',function(){
            document.querySelectorAll('.tab-btn').forEach(function(x){x.classList.remove('active');});b.classList.add('active');
            var tab=b.getAttribute('data-tab');
            document.querySelectorAll('.form-section').forEach(function(s){s.classList.remove('active');});
            document.getElementById(tab==='login'?'loginForm':'registerForm').classList.add('active');
        });
    });
    document.querySelectorAll('.nav-item').forEach(function(i){i.addEventListener('click',function(e){e.preventDefault();navigateTo(i.getAttribute('data-section'));});});
    document.querySelectorAll('.profile-tab').forEach(function(tab){
        tab.addEventListener('click',function(){
            document.querySelectorAll('.profile-tab').forEach(function(t){t.classList.remove('active');});tab.classList.add('active');
            document.querySelectorAll('.profile-content').forEach(function(c){c.classList.remove('active');});
            var pt=tab.getAttribute('data-ptab');
            document.getElementById('profile'+pt.charAt(0).toUpperCase()+pt.slice(1)).classList.add('active');
        });
    });
    var searchEl=document.getElementById('patientSearch');
    if(searchEl)searchEl.addEventListener('input',function(e){renderPatientsList(e.target.value);});
    var today=new Date().toISOString().split('T')[0];
    document.querySelectorAll('input[type="date"]').forEach(function(inp){if(!inp.value)inp.value=today;});
}

// ===== AUTH =====
function handleLogin(){
    var phone=document.getElementById('loginPhone').value.trim();
    var password=document.getElementById('loginPassword').value;
    if(!phone||!password){showToast(t('loginFailed'),'error');return;}
    var doctors=getDoctors();
    var doctor=doctors.find(function(d){return d.phone===phone&&d.password===password;});
    if(doctor){
        if(!doctor.approved){showToast(t('notApproved'),'warning');return;}
        currentUser=doctor;localStorage.setItem('sas4hc_currentUser',JSON.stringify(doctor));
        showMainApp();showToast(t('login')+' ✓','success');
    }else{showToast(t('loginFailed'),'error');}
}

function handleRegister(){
    var name=document.getElementById('regName').value.trim();
    var specialty=document.getElementById('regSpecialty').value;
    var clinic=document.getElementById('regClinic').value.trim();
    var phone=document.getElementById('regPhone').value.trim();
    var password=document.getElementById('regPassword').value;
    var confirm=document.getElementById('regConfirmPassword').value;
    if(!name||!phone||!password){showToast(t('registerFailed'),'error');return;}
    if(password!==confirm){showToast(t('passwordsNotMatch'),'error');return;}
    var doctors=getDoctors();
    if(doctors.find(function(d){return d.phone===phone;})){showToast(t('phoneExists'),'warning');return;}
    var newDoctor={id:'doc_'+Date.now(),name:name,specialty:specialty,clinic:clinic,phone:phone,password:password,approved:false,subscriptionExpiry:null,createdAt:new Date().toISOString()};
    doctors.push(newDoctor);saveDoctors(doctors);
    showToast(t('register')+' ✓','success');openPaymentModal();
}

function handleLogout(){
    currentUser=null;localStorage.removeItem('sas4hc_currentUser');
    document.getElementById('loginPage').classList.add('active');
    document.getElementById('mainApp').classList.remove('active');
}

function showMainApp(){
    document.getElementById('loginPage').classList.remove('active');
    document.getElementById('mainApp').classList.add('active');
    document.getElementById('sidebarDoctorName').textContent=currentUser.name;
    document.getElementById('sidebarDoctorSpecialty').textContent=t(currentUser.specialty);
    var sett=getSettings2();
    if(sett.clinicName)document.getElementById('settClinicName').value=sett.clinicName;
    if(sett.startTime)document.getElementById('settStartTime').value=sett.startTime;
    if(sett.endTime)document.getElementById('settEndTime').value=sett.endTime;
    if(sett.avgTime)document.getElementById('settAvgTime').value=sett.avgTime;
    navigateTo('dashboard');
}

// ===== NAVIGATION =====
function navigateTo(section){
    document.querySelectorAll('.content-section').forEach(function(s){s.classList.remove('active');});
    document.querySelectorAll('.nav-item').forEach(function(n){n.classList.remove('active');});
    var el=document.getElementById(section+'Section');
    if(el)el.classList.add('active');
    var nav=document.querySelector('.nav-item[data-section="'+section+'"]');
    if(nav)nav.classList.add('active');
    document.getElementById('pageTitle').textContent=t(section);
    renderAll();
    var sidebar=document.querySelector('.sidebar');
    if(sidebar)sidebar.classList.remove('open');
}

function toggleSidebar(){document.querySelector('.sidebar').classList.toggle('open');}

// ===== RENDER =====
function renderAll(){renderDashboard();renderQueue();renderServed();renderPatientsList();renderPatientProfile();renderSubscriptionStatus();}

function renderDashboard(){
    if(!currentUser)return;
    var patients=getPatients().filter(function(p){return p.doctorId===currentUser.id;});
    var queue=getQueue().filter(function(q){return q.doctorId===currentUser.id;});
    var served=getServed().filter(function(s){return s.doctorId===currentUser.id&&isToday(s.servedAt);});
    document.getElementById('totalPatients').textContent=patients.length;
    document.getElementById('todayServed').textContent=served.length;
    document.getElementById('inQueue').textContent=queue.length;
    document.getElementById('todayAppointments').textContent=queue.length+served.length;
    var dq=document.getElementById('dashQueueList');
    if(queue.length===0){dq.innerHTML='<div class="empty-state"><i class="fas fa-inbox"></i><p>'+t('noQueue')+'</p></div>';}
    else{dq.innerHTML=queue.slice(0,5).map(function(q){return '<div class="queue-item"><span class="queue-num">'+q.queueNumber+'</span><span class="queue-patient-name">'+q.patientName+'</span></div>';}).join('');}
    var dp=document.getElementById('dashPatientList');
    if(patients.length===0){dp.innerHTML='<div class="empty-state"><i class="fas fa-user-plus"></i><p>'+t('noPatients')+'</p></div>';}
    else{dp.innerHTML=patients.slice(-5).reverse().map(function(p){return '<div class="queue-item" style="cursor:pointer" onclick="viewPatient(''+p.id+'')"><span class="queue-num" style="background:'+(p.gender==='female'?'#FCE7F3':'#DBEAFE')+';color:'+(p.gender==='female'?'#DB2777':'#2563EB')+'">'+p.name.charAt(0)+'</span><span class="queue-patient-name">'+p.name+'</span></div>';}).join('');}
}

function renderQueue(){
    if(!currentUser)return;
    var queue=getQueue().filter(function(q){return q.doctorId===currentUser.id;});
    var serving=queue.find(function(q){return q.status==='serving';});
    if(serving){document.getElementById('currentServing').textContent=serving.queueNumber;document.getElementById('servingPatientInfo').innerHTML='<strong>'+serving.patientName+'</strong>';}
    else{document.getElementById('currentServing').textContent='--';document.getElementById('servingPatientInfo').innerHTML='<span>'+t('noOneServing')+'</span>';}
    document.getElementById('queueCount').innerHTML=queue.length+' <span>'+t('patients_lower')+'</span>';
    var ql=document.getElementById('queueList');
    if(queue.length===0){ql.innerHTML='<div class="empty-state"><i class="fas fa-inbox"></i><p>'+t('noQueue')+'</p></div>';}
    else{ql.innerHTML=queue.map(function(q){return '<div class="queue-item"><span class="queue-num">'+q.queueNumber+'</span><span class="queue-patient-name">'+q.patientName+'</span><span class="queue-patient-phone">'+(q.patientPhone||'')+'</span><div class="queue-actions-item"><button class="btn-call" onclick="callSpecificPatient(''+q.id+'')" title="'+t('callPatient')+'"><i class="fas fa-bullhorn"></i></button><button class="btn-remove" onclick="removeFromQueue(''+q.id+'')" title="'+t('remove')+'"><i class="fas fa-times"></i></button></div></div>';}).join('');}
}

function renderServed(){
    if(!currentUser)return;
    var served=getServed().filter(function(s){return s.doctorId===currentUser.id&&isToday(s.servedAt);});
    document.getElementById('servedCount').textContent=served.length;
    var sl=document.getElementById('servedList');
    if(served.length===0){sl.innerHTML='<div class="empty-state"><i class="fas fa-check-circle"></i><p>'+t('noOneServed')+'</p></div>';}
    else{sl.innerHTML=served.map(function(s){return '<div class="served-item"><span class="served-num">'+s.queueNumber+'</span><span class="served-name">'+s.patientName+'</span><span class="served-time">'+new Date(s.servedAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})+'</span></div>';}).join('');}
}

function renderPatientsList(search){
    if(!currentUser)return;
    search=search||'';
    var patients=getPatients().filter(function(p){return p.doctorId===currentUser.id;});
    if(search){var s=search.toLowerCase();patients=patients.filter(function(p){return p.name.toLowerCase().includes(s)||(p.phone&&p.phone.includes(s));});}
    var pl=document.getElementById('patientsList');
    if(patients.length===0){pl.innerHTML='<div class="empty-state"><i class="fas fa-user-plus"></i><p>'+t('noPatients')+'</p></div>';}
    else{pl.innerHTML=patients.map(function(p){return '<div class="patient-card" onclick="viewPatient(''+p.id+'')"><div class="patient-card-avatar '+p.gender+'">'+p.name.charAt(0)+'</div><div class="patient-card-info"><div class="patient-card-name">'+p.name+'</div><div class="patient-card-meta">'+p.age+' '+t('yearsOld')+' · '+t(p.gender)+'</div></div></div>';}).join('');}
}

function renderPatientProfile(){
    if(!currentPatientId)return;
    var patients=getPatients();
    var p=patients.find(function(x){return x.id===currentPatientId;});
    if(!p)return;
    document.getElementById('profileName').textContent=p.name;
    document.getElementById('profileBasicInfo').textContent=p.age+' '+t('yearsOld')+' · '+t(p.gender);
    document.getElementById('profFullName').textContent=p.name;
    document.getElementById('profAge').textContent=p.age;
    document.getElementById('profGender').textContent=t(p.gender);
    document.getElementById('profPhone').textContent=p.phone||'---';
    document.getElementById('profBlood').textContent=p.bloodType||'---';
    document.getElementById('profAddress').textContent=p.address||'---';
    document.getElementById('profAllergies').textContent=p.allergies||'---';
    document.getElementById('profChronic').textContent=p.chronicDiseases||'---';
    document.getElementById('profNotes').textContent=p.notes||'---';
    var rl=document.getElementById('reportsList');
    if(!p.reports||p.reports.length===0){rl.innerHTML='<div class="empty-state"><i class="fas fa-file-medical"></i><p>'+t('noReports')+'</p></div>';}
    else{rl.innerHTML=p.reports.map(function(r){return '<div class="report-item"><div class="report-header"><span class="report-title">'+r.title+'</span><span class="report-type-badge badge-'+(r.type||'other')+'">'+t(r.type||'other')+'</span></div><div class="report-date">'+r.date+'</div><div class="report-content">'+r.content+'</div></div>';}).join('');}
    var tl=document.getElementById('testsList');
    if(!p.tests||p.tests.length===0){tl.innerHTML='<div class="empty-state"><i class="fas fa-flask"></i><p>'+t('noTests')+'</p></div>';}
    else{tl.innerHTML=p.tests.map(function(r){return '<div class="test-item"><div class="test-header"><span class="test-name">'+r.name+'</span><span class="test-status-badge badge-'+(r.status||'pending')+'">'+t(r.status||'pending')+'</span></div><div class="test-date-label">'+r.date+'</div><div class="test-result-text">'+r.result+'</div></div>';}).join('');}
    var vl=document.getElementById('visitsList');
    if(!p.visits||p.visits.length===0){vl.innerHTML='<div class="empty-state"><i class="fas fa-clipboard-list"></i><p>'+t('noVisits')+'</p></div>';}
    else{vl.innerHTML=p.visits.map(function(v){return '<div class="visit-item"><div class="visit-header"><span class="visit-date">'+v.date+'</span></div><div class="visit-time">'+v.time+'</div><div class="visit-notes">'+v.notes+'</div></div>';}).join('');}
}

function renderSubscriptionStatus(){
    if(!currentUser)return;
    var isActive=currentUser.approved&&(currentUser.subscriptionExpiry&&new Date(currentUser.subscriptionExpiry)>new Date());
    var indicator=document.getElementById('subIndicator');
    indicator.className='sub-indicator '+(isActive?'active':'inactive');
    indicator.innerHTML=isActive?'<i class="fas fa-check-circle"></i>':'<i class="fas fa-times-circle"></i>';
    document.getElementById('subStatusText').textContent=isActive?t('active'):t('inactive');
    document.getElementById('subExpiry').textContent=currentUser.subscriptionExpiry?new Date(currentUser.subscriptionExpiry).toLocaleDateString():'---';
}

// ===== QUEUE OPERATIONS =====
function callNextPatient(){
    if(!currentUser)return;
    var queue=getQueue().filter(function(q){return q.doctorId===currentUser.id;});
    var current=queue.find(function(q){return q.status==='serving';});
    if(current){
        var allQueue=getQueue();
        var idx=allQueue.findIndex(function(q){return q.id===current.id;});
        if(idx>=0){allQueue[idx].status='served';saveQueue(allQueue);}
        var served=getServed();
        served.push({id:'sv_'+Date.now(),doctorId:currentUser.id,patientId:current.patientId,patientName:current.patientName,queueNumber:current.queueNumber,servedAt:new Date().toISOString()});
        saveServed(served);
        addVisitToPatient(current.patientId);
    }
    var waiting=queue.filter(function(q){return q.status==='waiting';});
    if(waiting.length===0){showToast(t('queueEmpty'),'info');renderAll();return;}
    var next=waiting[0];
    var allQ=getQueue();
    var idx2=allQ.findIndex(function(q){return q.id===next.id;});
    if(idx2>=0){allQ[idx2].status='serving';saveQueue(allQ);}
    showCallNotification(next.patientName,next.queueNumber,currentUser.name);
    renderAll();
}

function callSpecificPatient(qId){
    if(!currentUser)return;
    var queue=getQueue();
    var current=queue.find(function(q){return q.doctorId===currentUser.id&&q.status==='serving';});
    if(current){
        var idx=queue.findIndex(function(q){return q.id===current.id;});
        if(idx>=0){queue[idx].status='served';}
        var served=getServed();
        served.push({id:'sv_'+Date.now(),doctorId:currentUser.id,patientId:current.patientId,patientName:current.patientName,queueNumber:current.queueNumber,servedAt:new Date().toISOString()});
        saveServed(served);
        addVisitToPatient(current.patientId);
    }
    var target=queue.find(function(q){return q.id===qId;});
    if(target){target.status='serving';saveQueue(queue);showCallNotification(target.patientName,target.queueNumber,currentUser.name);renderAll();}
}

function removeFromQueue(qId){var queue=getQueue().filter(function(q){return q.id!==qId;});saveQueue(queue);renderAll();}

function addVisitToPatient(patientId){
    if(!patientId)return;
    var patients=getPatients();
    var p=patients.find(function(x){return x.id===patientId;});
    if(p){
        if(!p.visits)p.visits=[];
        p.visits.push({date:new Date().toLocaleDateString(),time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),notes:'Visit - '+new Date().toLocaleDateString()});
        savePatients(patients);
    }
}

function showCallNotification(name,num,docName){
    document.getElementById('callPatientName').textContent=name;
    document.getElementById('callQueueNumber').textContent='#'+num;
    document.getElementById('callDoctorName').textContent='Dr. '+docName;
    document.getElementById('callOverlay').classList.add('active');
    try{var ctx=new(window.AudioContext||window.webkitAudioContext)();var osc=ctx.createOscillator();var gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);osc.frequency.value=800;osc.type='sine';gain.gain.value=0.3;osc.start();osc.stop(ctx.currentTime+0.3);}catch(e){}
}

function dismissCall(){document.getElementById('callOverlay').classList.remove('active');}

// ===== PATIENT OPERATIONS =====
function openAddPatientModal(){resetModalFields();openModal('addPatientModal');}

function resetModalFields(){
    document.getElementById('patientName').value='';
    document.getElementById('patientAge').value='';
    document.getElementById('patientPhone').value='';
    document.getElementById('patientAddress').value='';
    document.getElementById('patientAllergies').value='';
    document.getElementById('patientChronic').value='';
    document.getElementById('patientNotes').value='';
    document.getElementById('patientBlood').value='';
    document.getElementById('patientGender').value='male';
    document.getElementById('addToQueue').checked=true;
}

function savePatient(){
    if(!currentUser)return;
    var name=document.getElementById('patientName').value.trim();
    var age=parseInt(document.getElementById('patientAge').value)||0;
    var gender=document.getElementById('patientGender').value;
    var phone=document.getElementById('patientPhone').value.trim();
    var bloodType=document.getElementById('patientBlood').value;
    var address=document.getElementById('patientAddress').value.trim();
    var allergies=document.getElementById('patientAllergies').value.trim();
    var chronicDiseases=document.getElementById('patientChronic').value.trim();
    var notes=document.getElementById('patientNotes').value.trim();
    var addToQueue=document.getElementById('addToQueue').checked;
    if(!name){showToast(t('registerFailed'),'error');return;}
    var newPatient={id:'pat_'+Date.now(),doctorId:currentUser.id,name:name,age:age,gender:gender,phone:phone,bloodType:bloodType,address:address,allergies:allergies,chronicDiseases:chronicDiseases,notes:notes,reports:[],tests:[],visits:[],createdAt:new Date().toISOString()};
    var patients=getPatients();patients.push(newPatient);savePatients(patients);
    if(addToQueue){
        var qNum=getNextQueueNum();
        var queue=getQueue();
        queue.push({id:'q_'+Date.now(),doctorId:currentUser.id,patientId:newPatient.id,patientName:name,patientPhone:phone,queueNumber:qNum,status:'waiting',addedAt:new Date().toISOString()});
        saveQueue(queue);
    }
    closeModal('addPatientModal');showToast(t('patientAdded'),'success');renderAll();
}

function viewPatient(id){currentPatientId=id;navigateTo('patientProfile');}

function openEditPatientModal(){
    if(!currentPatientId)return;
    var p=getPatients().find(function(x){return x.id===currentPatientId;});
    if(!p)return;
    document.getElementById('patientName').value=p.name;
    document.getElementById('patientAge').value=p.age;
    document.getElementById('patientGender').value=p.gender;
    document.getElementById('patientPhone').value=p.phone||'';
    document.getElementById('patientBlood').value=p.bloodType||'';
    document.getElementById('patientAddress').value=p.address||'';
    document.getElementById('patientAllergies').value=p.allergies||'';
    document.getElementById('patientChronic').value=p.chronicDiseases||'';
    document.getElementById('patientNotes').value=p.notes||'';
    document.getElementById('addToQueue').checked=false;
    openModal('addPatientModal');
    var saveBtn=document.querySelector('#addPatientModal .modal-footer .btn-primary');
    saveBtn.onclick=function(){
        var patients=getPatients();
        var idx=patients.findIndex(function(x){return x.id===currentPatientId;});
        if(idx>=0){
            patients[idx].name=document.getElementById('patientName').value.trim();
            patients[idx].age=parseInt(document.getElementById('patientAge').value)||0;
            patients[idx].gender=document.getElementById('patientGender').value;
            patients[idx].phone=document.getElementById('patientPhone').value.trim();
            patients[idx].bloodType=document.getElementById('patientBlood').value;
            patients[idx].address=document.getElementById('patientAddress').value.trim();
            patients[idx].allergies=document.getElementById('patientAllergies').value.trim();
            patients[idx].chronicDiseases=document.getElementById('patientChronic').value.trim();
            patients[idx].notes=document.getElementById('patientNotes').value.trim();
            savePatients(patients);closeModal('addPatientModal');showToast(t('settingsSaved'),'success');renderAll();
        }
        saveBtn.onclick=savePatient;
    };
}

// ===== REPORT OPERATIONS =====
function openAddReportModal(){openModal('addReportModal');}

function saveReport(){
    if(!currentPatientId)return;
    var title=document.getElementById('reportTitle').value.trim();
    var date=document.getElementById('reportDate').value;
    var type=document.getElementById('reportType').value;
    var content=document.getElementById('reportContent').value.trim();
    if(!title){showToast(t('registerFailed'),'error');return;}
    var patients=getPatients();
    var p=patients.find(function(x){return x.id===currentPatientId;});
    if(p){if(!p.reports)p.reports=[];p.reports.push({id:'rpt_'+Date.now(),title:title,date:date,type:type,content:content});savePatients(patients);}
    closeModal('addReportModal');showToast(t('reportAdded'),'success');renderPatientProfile();
}

// ===== TEST OPERATIONS =====
function openAddTestModal(){openModal('addTestModal');}

function saveTest(){
    if(!currentPatientId)return;
    var name=document.getElementById('testName').value.trim();
    var date=document.getElementById('testDate').value;
    var result=document.getElementById('testResult').value.trim();
    var status=document.getElementById('testStatus').value;
    if(!name){showToast(t('registerFailed'),'error');return;}
    var patients=getPatients();
    var p=patients.find(function(x){return x.id===currentPatientId;});
    if(p){if(!p.tests)p.tests=[];p.tests.push({id:'tst_'+Date.now(),name:name,date:date,result:result,status:status});savePatients(patients);}
    closeModal('addTestModal');showToast(t('testAdded'),'success');renderPatientProfile();
}

// ===== SUBSCRIPTION =====
function openPaymentModal(){openModal('paymentModal');}

// ===== SETTINGS =====
function saveSettings(){
    var sett={clinicName:document.getElementById('settClinicName').value,startTime:document.getElementById('settStartTime').value,endTime:document.getElementById('settEndTime').value,avgTime:document.getElementById('settAvgTime').value};
    saveSettings2(sett);showToast(t('settingsSaved'),'success');
}

// ===== MODALS =====
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}

// ===== TOAST =====
function showToast(msg,type){
    type=type||'info';
    var container=document.getElementById('toastContainer');
    var icons={success:'fa-check-circle',error:'fa-exclamation-circle',warning:'fa-exclamation-triangle',info:'fa-info-circle'};
    var toast=document.createElement('div');
    toast.className='toast '+type;
    toast.innerHTML='<span class="toast-icon"><i class="fas '+icons[type]+'"></i></span><span class="toast-message">'+msg+'</span>';
    container.appendChild(toast);
    setTimeout(function(){toast.style.opacity='0';toast.style.transform='translateX(100%)';setTimeout(function(){toast.remove();},300);},3000);
}

function togglePassword(id){var inp=document.getElementById(id);if(inp.type==='password')inp.type='text';else inp.type='password';}
function showNotifications(){showToast('No new notifications','info');}

// ===== DEMO APPROVE =====
function demoApprove(){
    var doctors=getDoctors();
    doctors.forEach(function(d){d.approved=true;d.subscriptionExpiry=new Date(Date.now()+30*24*60*60*1000).toISOString();});
    saveDoctors(doctors);
    if(currentUser){currentUser.approved=true;currentUser.subscriptionExpiry=new Date(Date.now()+30*24*60*60*1000).toISOString();localStorage.setItem('sas4hc_currentUser',JSON.stringify(currentUser));}
    showToast('Demo: Accounts activated!','success');renderAll();
}

document.addEventListener('DOMContentLoaded',init);
